import React, { Component } from 'react';
import { App } from './src/App';
export function ComponentPreview() {
  return <div className="w-full min-h-screen">
      <App />
    </div>;
}