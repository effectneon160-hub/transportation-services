import React, { Component } from 'react';
import './index.css';
import { render } from 'react-dom';
import { ComponentPreview } from './ComponentPreview';
render(<ComponentPreview />, document.getElementById('root'));