import React from 'react';
export { App } from './App';